import Header from "@/components/clinic/Header";
import Hero from "@/components/clinic/Hero";
import Services from "@/components/clinic/Services";
import Booking from "@/components/clinic/Booking";
import Contact from "@/components/clinic/Contact";
import Footer from "@/components/clinic/Footer";

export default function Page() {
  return (
    <main dir="rtl" className="min-h-screen">
      {/* الخلفية الزرقاء الزجاجية */}
      <div className="fixed inset-0 -z-20">
        <div className="h-full w-full bg-gradient-to-br from-[#0b1b3a] via-[#123a7a] to-[#0b1b3a]" />
        <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.18),transparent_55%)]" />
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(ellipse_at_bottom,rgba(0,255,255,0.12),transparent_55%)]" />
      </div>

      {/* ✅ Header ثابت فوق */}
      <div className="sticky top-0 z-50">
        <div className="bg-[#0b1b3a]/60 backdrop-blur-md border-b border-white/10">
          <Header />
        </div>
      </div>

      {/* Hero مع صورة chair.png */}
      <section className="relative min-h-[70vh]">
        {/* خلفية صورة */}
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center"
          style={{ backgroundImage: "url('/chair.png')" }}
        />
        {/* تغميق بسيط */}
        <div className="absolute inset-0 -z-10 bg-black/25 pointer-events-none" />

        {/* ✅ أيقونات (مش ثابتة) داخل الهيرو - أعلى يمين */}
        <div className="absolute top-4 right-4 z-20 flex gap-2">
          <a
            href="https://facebook.com/PUT_YOUR_PAGE"
            target="_blank"
            rel="noreferrer"
            aria-label="Facebook"
            title="Facebook"
            className="h-9 w-9 rounded-full bg-[#0b1b3a]/60 border border-white/20 backdrop-blur-xl flex items-center justify-center hover:bg-[#0b1b3a]/80 transition"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-white">
              <path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.23.2 2.23.2v2.46h-1.26c-1.24 0-1.62.77-1.62 1.56V12h2.76l-.44 2.89h-2.32v6.99A10 10 0 0 0 22 12z" />
            </svg>
          </a>

          <a
            href="https://instagram.com/PUT_YOUR_PAGE"
            target="_blank"
            rel="noreferrer"
            aria-label="Instagram"
            title="Instagram"
            className="h-9 w-9 rounded-full bg-[#0b1b3a]/60 border border-white/20 backdrop-blur-xl flex items-center justify-center hover:bg-[#0b1b3a]/80 transition"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-white">
              <path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm10 2H7a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zm-5 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm4.8-.9a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
            </svg>
          </a>

          <a
            href="https://www.google.com/maps?q=PUT_LAT,PUT_LNG"
            target="_blank"
            rel="noreferrer"
            aria-label="Google Maps"
            title="Google Maps"
            className="h-9 w-9 rounded-full bg-[#0b1b3a]/60 border border-white/20 backdrop-blur-xl flex items-center justify-center hover:bg-[#0b1b3a]/80 transition"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5 fill-white">
              <path d="M12 2a7 7 0 0 0-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z" />
            </svg>
          </a>
        </div>

        {/* محتوى الهيرو */}
        <div className="relative z-10 text-white">
          <Hero />
        </div>
      </section>

      {/* باقي الصفحة */}
      <Services />
      <Booking />
      <Contact />
      <Footer />
    </main>
  );
}
